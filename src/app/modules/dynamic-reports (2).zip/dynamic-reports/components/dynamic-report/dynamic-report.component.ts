import { Component, OnInit } from '@angular/core';
import { DynamicReportService } from '../dynamicReport.service';
import { TableUtil } from 'src/app/utils/excelexport';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
// import { TableUtil } from 'src/app/utils/excelexport';
@Component({
  selector: 'app-dynamic-report',

  templateUrl: './dynamic-report.component.html',
  styleUrls: ['./dynamic-report.component.scss'],
})
export class DynamicReportComponent implements OnInit {
  categoryList: any;
  categoryListId: number;
  subCategory: boolean = false;
  subCategoryListId: number;
  ReportListByCategoryAndSubCategory: any;
  selectedReport: any = null;
  showDiv1: boolean = false;
  activeButtonId: number | null = null;
  reportListId: any;
  isTimeoutExpires: boolean = false;
  // timesetting for downloading the reports
  timeDuration = 1 * 1000;
  // timeDuration =   2 * 60* 60 * 60 *1000;
  timeoutEnd: Date;
  currentTime: Date = new Date();
  activeContentIndex: number = -1;
  subCategoryList: any;
  reportFilterList: any;
  sheduleSelectedDate: string | null = null;
  isActive: boolean = false;
  divWidth: string = '100%';
  displayDiv: boolean = false;
  displayDiv1: boolean = false;
  displayDiv2: boolean = false;
  displayDiv3: boolean = false;
  displayDiv4: boolean = false;
  displayDiv5: boolean = false;
  chapterList: any;
  programCodeList: any;
  signUpCodeList: any;
  chapter: string;
  programcode: string;
  signupcode: string;
  chapterCode: any;
  classInput: any;
  subClassInput: any;
  sessionInput: any;
  others: any;
  classCode: any;
  subClassCode: any;
  sessionCode: any;
  // for saving selecetd dropdwon option
  classcode: any;
  subclasscode: any;
  sessioncode: any;
  signupCategory: any;
  isChecked: any;
  chapterListSelecetd: any = [];
  programListSelected: any = [];
  programListSelected2: any[] = [];
  signupListSelected: any[] = [];
  classListSelected: any[] = [];
  classListSelected2: any[] = [];
  subclassSelected: any[] = [];
  subclassListSelected2: any[] = [];
  sessionSelected: any[] = [];
  sessionListSelected2: any[] = [];
  reportId: any;
  reportName: any;
  saveReportSchedule: any;
  programCodePairs: { key: string; value: any }[] = [];
  signUpCodePairs: { key: string; value: any }[] = [];
  classCodePairs: { key: string; value: any }[] = [];
  subclassCodePairs: { key: string; value: any }[] = [];
  sessionCodePairs: { key: string; value: any }[] = [];
  selectedTime: any;
  // familyReportName:any;
  hasDotError: boolean = false;
  myForm: FormGroup;
  form: FormGroup;
  familyReportName: string = '';
  familyReportNameError: boolean = false;
  scheduleDate: any;
  datevalidation: boolean = false;
  filterList: { key : string ; value : any}[]=[];
  constructor(
    private dynamicReports: DynamicReportService,
    private fb: FormBuilder
  ) {
    this.myForm = this.fb.group({
      dateTime: ['', Validators.required],
    });
    this.form = this.fb.group({
      scheduleDate: ['', Validators.required],
    });
  }

  markAsTouched() {
    this.scheduleDate.markAsTouched();
    this.datevalidation = true;
  }

  validateFamilyReportName(value: string): void {
    this.familyReportNameError = !value || value.includes('.');
    // Check if the value contains a dot
    // if (value.includes('.')) {
    //   this.hasDotError = true;
    // } else {
    //   this.hasDotError = false;
    // }

    // Remove dots from the input value
    this.familyReportName = value.replace(/\./g, '');
  }

  buttonscolors: string[] = [
    '#F79646',
    '#55c2da',
    '#77933C',
    '#984807',
    '#948A54',
    '#002060',
    '#8064A2',
    '#0070C0',
  ];
  toppings = new FormControl('');

  toppingList: string[] = [
    'Extra cheese',
    'Mushroom',
    'Onion',
    'Pepperoni',
    'Sausage',
    'Tomato',
  ];

  inputArrays: string[] = [
    'date',
    'string',
    'date',
    'dropdown',
    'radio',
    'checkbox',
  ];
  ngOnInit() {
    this.fetchCategoryList();
    this.fetchChapterLists();
  }
  //  for time based download button enable
  setTimeout() {
    const now = new Date();
    this.timeoutEnd = new Date(now.getTime() + this.timeDuration);
    console.log('thi sis inside setTime out function and the now is ' + now);
    console.log('the timeoutEnd is :' + this.timeoutEnd);
  }

  isTimeoutExpired(): boolean {
    let timeOut = new Date() > this.timeoutEnd;

    return timeOut;
  }
  // For fetching category List

  async fetchCategoryList() {
    try {
      this.categoryList = await this.dynamicReports.fetchCategoryList();
      console.log('fetched category list is : ', this.categoryList);
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  // for fetching sub category list based on category
  async fetchSubCategoryList(parameters: any) {
    if (this.displayDiv) {
      this.displayDiv = !this.displayDiv;
    }
    this.divWidth = '100%';

    if (!this.displayDiv) {
      console.log('changed the subcat into true');
      this.displayDiv = this.displayDiv;
    }
    // if(this.displayDiv1){
    //   console.log("::::::::::it's came to if loop this.displayDiv1 ::::::::::");
    //   this.displayDiv1=!this.displayDiv1;
    //   }
    //   else if (this.displayDiv1) {
    //     console.log("::::::::it's came to else loop this.displayDiv1 ::::::::::");
    //     this.displayDiv1=!this.displayDiv1
    //   }
    this.categoryListId = parameters;
    this.subCategory = false;
    try {
      let param = {
        id: parameters,
      };
      this.subCategoryList = await this.dynamicReports.fetchSubCategoryList(
        param
      );
      console.log('fetched subCategory list is : ', this.subCategoryList);
      this.subCategory = true;
      this.isActive = true;
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  // getting button colors dynamically
  getButtonColor(index: number): string {
    return this.buttonscolors[index % this.buttonscolors.length];
  }

  // code for exporting to excel
  //   exportExcel() {
  //     console.log('the excel icon is clicked');
  // //     if(!this.displayDiv5){
  // // this.displayDiv5=true;
  // //     }
  // // TableUtil.exportTableToExcel('familyTable','familytable data')
  // TableUtil.exportArrayToExcel(this.familyData,'Family Report');
  //     // TableUtil.exportArrayToExcel(this.totalRecList,"exportedExcelSheetofDemo");
  //     // this.downloadReport();
  //     this.displayDiv = !this.displayDiv;
  //     this.divWidth = '100%';
  //   }

  // downloadReport(){
  //   TableUtil.exportArrayToExcel(this.familyData,'Family Report');
  // }
  ReportsList(parameters: any) {
    if (this.displayDiv) {
      console.log(
        "::::::::::it's came  to ReportList if loop this.displayDiv1 ::::::::::"
      );
      this.displayDiv = !this.displayDiv;
    } else {
      console.log(
        "::::::::it's came to ReportList else loop this.displayDiv1 ::::::::::"
      );
      this.displayDiv = this.displayDiv;
    }
    this.subCategoryListId = parameters;
    this.setTimeout();
    // calling the fetchReportListByCategoryAndSubCategory
    this.fetchReportListByCategoryAndSubCategory();

    // Toggle width between 200px and 400px (or any value you like)
    this.divWidth = this.divWidth === '100%' ? '50%' : '100%';
    this.displayDiv = !this.displayDiv;
    this.displayDiv1 = !this.displayDiv1;
    this.displayDiv2 = !this.displayDiv2;
    this.displayDiv3 = !this.displayDiv3;
  }

  // fetchReportListByCategoryAndSubCategory

  async fetchReportListByCategoryAndSubCategory() {
    if (this.displayDiv1) {
      console.log(
        "::::::::::it's came  to ReportList if loop this.displayDiv1 ::::::::::"
      );
      this.displayDiv1 = !this.displayDiv1;
    }
    try {
      let parameters = {
        categoryId: this.categoryListId,
        subCategoryId: this.subCategoryListId,
        // categoryId: 0,
        // subCategoryId: 0,
      };
      this.ReportListByCategoryAndSubCategory =
        await this.dynamicReports.fetchReportListByCategoryAndSubCategory(
          parameters
        );
      // this.ReportListByCategoryAndSubCategory = this.rll;

      console.log(
        'fetched subCategory list is : ',
        this.ReportListByCategoryAndSubCategory
      );
      for (let item of this.ReportListByCategoryAndSubCategory) {
        this.reportName = item.reportName;
        this.reportId = item.reportId;
        console.log(
          'the report id is :' +
            this.reportId +
            ' and the report name is :' +
            this.reportName
        );
      }
      // this.fetchReportFilterListByReportId(this.reportListId)
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  async fetchReportFilterListByReportId(parameter: any) {
    try {
      let param = {
        id: parameter,
      };
      this.reportFilterList =
        await this.dynamicReports.fetchReportFilterListByReportId(param);
      console.log('fetched filtered Report list is : ', this.reportFilterList);
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  Content(parameter: number) {
    this.activeContentIndex = -1;

    if (this.activeContentIndex === parameter) {
      this.activeContentIndex = -1;
    } else {
      this.sheduleSelectedDate = null;
      this.activeContentIndex = parameter;
    }
    console.log('the parameters of index is ' + parameter);

    switch (parameter) {
      case 0:
        console.log('This is inside switch and the value is 0');
        this.displayDiv1 = !this.displayDiv1;
        break;
      case 1:
        console.log('This is inside switch and the value is 1');
        this.displayDiv1 = !this.displayDiv1;
        break;
      case 2:
        console.log('This is inside switch and the value is 2');
        this.displayDiv1 = !this.displayDiv1;
        break;
      default:
        console.log('This is inside switch and the value is default');
        this.displayDiv1 = !this.displayDiv1;
        break;
    }
  }

  Content4() {
    this.displayDiv4 = !this.displayDiv4; // Toggle the display state
  }

  setActiveButton(buttonId: number): void {
    // this.activeButtonId = buttonId;
    if (this.activeButtonId === buttonId) {
      // If the same button is clicked again, toggle off
      this.activeButtonId = null; // or -1 if you prefer
    } else {
      // Otherwise, set the new active button
      this.activeButtonId = buttonId;
    }
  }
  handleButtonClick(buttonId: number): void {
    this.fetchSubCategoryList(buttonId); // Fetch subcategory list
    this.Content4(); // Perform other action
    this.setActiveButton(buttonId); // Toggle button state
  }
  parameter: any = 0;

  // This method sets the value of 'parameter' based on the button clicked
  setParameter(value: any): void {
    this.parameter = value;
  }

  reportSheduledfunction() {
    this.isTimeoutExpires = true;
    console.log(
      'report was sheduled successfully and the sheduled date is given below '
    );
    console.log(this.sheduleSelectedDate);
  }

  async fetchChapterLists() {
    try {
      const data = await this.dynamicReports.fetchChapterLists();

      // Check if data is an object
      if (data && typeof data === 'object') {
        this.chapterList = data; // Initialize chapterList as an empty array

        for (const key in data) {
          if (data.hasOwnProperty(key)) {
            // Push key-value pair as an object into the chapterList array
            // this.chapterList.push({ key, value: data[key] });
          }
        }

        console.log('Chapter Code: ', this.chapterList);
      } else {
        console.error('Fetched data is not an object:', data);
      }
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  // chat gpt code both program and signup codes

  async fetchProgramCode(chapterCode: string, isChecked: boolean) {
    console.log(
      'this is inside fetch program code' + chapterCode + '  ... ' + isChecked
    );
    // Initialize or reset the program list
    if (isChecked) {
      // If the checkbox is checked, add the chapterCode to the list
      if (!this.chapterListSelecetd.includes(chapterCode)) {
        this.chapterListSelecetd.push(chapterCode);
        this.filterList.push({key:"chapter List", value:chapterCode})
        console.log('chapterListSelecetd checked: ' + this.chapterListSelecetd);
      }
    } else {
      // If the checkbox is unchecked, remove the chapterCode from the list
      this.chapterListSelecetd = this.chapterListSelecetd.filter(
        (code: string) => code !== chapterCode
      );
      // this.filterList = this.filterList.filter(
      //   // (key:string, value:string) => {key = "chapter List", value !== chapterCode}
      // )

      console.log('chapterListSelecetd unchecked: ' + this.chapterListSelecetd);
    }

    // Reset the program list
    this.programListSelected = [];
    try {
      // Loop through the list of selected chapters
      for (let item of this.chapterListSelecetd) {
        const parameter = { code: item, programCategory: '' };
        this.programCodeList = await this.dynamicReports.fetchProgramCode(
          parameter
        );
        this.programCodeList.forEach((program: any) => {
          if (!this.programListSelected.includes(program)) {
            this.programListSelected.push(program);
            this.programCodePairs.push({
              key: item,
              value: program.description,
            });
          }
        });
      }

      // Check if any signUpCode matches the program.description
      this.signupListSelected.forEach((signup: any) => {
        const matchingKey = this.programCodePairs.find(
          (kv) => kv.value === signup.signUpCode
        );
        if (matchingKey) {
          console.log('Matching Key for SignUpCode:', matchingKey.key);
        }
      });

      console.log('Program Code List: ', this.programListSelected);
      console.log('Key-Value Pairs of program code: ', this.programCodePairs);
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  async fetchSignupCode(signupCode: string, isChecked: boolean) {

    console.log('this is inside the fetch signupcode: ' + signupCode);

    if (isChecked) {
      // If the checkbox is checked, add the signupCode to the list
      if (!this.programListSelected2.includes(signupCode)) {
        this.programListSelected2.push(signupCode);
        this.filterList.push({key:"program code", value:signupCode})
      }
    } else {
      // If the checkbox is unchecked, remove the signupCode from the list
      this.programListSelected2 = this.programListSelected2.filter(
        (code: string) => code !== signupCode
      );
    }
    try {
      // for (let item of this.programListSelected2) {
      const parameter = { programCode: signupCode };

      const signUpCodeList = await this.dynamicReports.fetchSignUpCode(
        parameter
      );
      signUpCodeList.forEach((program: any) => {
        this.signUpCodePairs.push({
          key: signupCode,
          value: program.signUpCode,
        });
        if (!this.signupListSelected.includes(program)) {
          this.signupListSelected.push(program);
        }
      });
      // }

      console.log('SignUp Code List: ', this.signupListSelected);
      console.log('Key-Value Pairs of signup code: ', this.signUpCodePairs);
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }
  getprogramcode(parameter: any) {
    console.log('Hi this is from get program code got ' + parameter);
    console.log(this.signUpCodePairs);
    for (let item of this.signUpCodePairs) {
      if (item.value === parameter) {
        console.log(
          'the key is:' + item.key + ' and the value is ' + item.value
        );
        this.programcode = item.key;
      }
    }
  }

  getsignupcode(classic: any) {
    let parameforprogramcode = '';
    console.log('Hi this is from get signup code got ' + classic);
    console.log(this.classCodePairs);
    for (let item of this.classCodePairs) {
      if (item.value === classic) {
        parameforprogramcode = item.key;
        console.log(
          'the key is:' + item.key + ' and the value is ' + item.value
        );
        this.signupcode = item.key;
      }
    }
    this.getprogramcode(parameforprogramcode);
  }

  // getclasscode(parameters);
  getclasscode(parameters: any) {
    let paramforclasscode = '';
    console.log(
      'Hi this is from get class code function and the got param is :' +
        parameters
    );
    console.log(this.subclassCodePairs);
    for (let item of this.subclassCodePairs) {
      if (parameters === item.value) {
        paramforclasscode = item.key;
        console.log(
          'the key is :' + item.key + ' and the value is ' + item.value
        );
        this.classcode = item.key;
      }
    }
    this.getsignupcode(paramforclasscode);
  }

  async fetchClassCode(parameters: any, isChecked: boolean) {
    console.log(
      'Hi this is from class code function on ts ' +
        parameters +
        ' and the boolean is ' +
        isChecked
    );
    this.getprogramcode(parameters);
    if (isChecked) {
      // If the checkbox is checked, add the signupCode to the list
      if (!this.classListSelected.includes(parameters)) {
        this.classListSelected.push(parameters);
        this.filterList.push({key:"Signup code", value:parameters})
      }
    } else {
      // If the checkbox is unchecked, remove the signupCode from the list
      this.classListSelected = this.classListSelected.filter(
        (code: string) => code !== parameters
      );
    }

    console.log('The signup code is ' + parameters);
    this.signupcode = parameters;

    try {
      const parameter = {
        programCode: this.programcode,
        chapterCode: 'string',
        signupCodeCategory: 0,
        signupCode: this.signupcode,
        classCode: 'string',
        subClassCode: 'string',
      };

      this.classCode = await this.dynamicReports.fetchClassCode(parameter);

      this.classCode.forEach((program: any) => {
        if (!this.classListSelected2.includes(program)) {
          this.classListSelected2.push(program);
          console.log('classList Selected 2 : ' + this.classListSelected2);

          this.classCodePairs.push({
            key: this.signupcode,
            value: program.description,
          });
        }
      });

      console.log('Class Code List: ', this.classCode);
      console.log('Key-Value Pair of class code: ', this.classCodePairs);
    } catch (error) {
      console.error('Error while fetching the data: ' + error);
    }
  }

  async fetchSubClassCode(parameters: any, isChecked: boolean) {
    this.getsignupcode(parameters);
    if (isChecked) {
      if (!this.subclassSelected.includes(parameters)) {
        this.subclassSelected.push(parameters);
        this.filterList.push({key:"class", value:parameters})
      }
    } else {
      this.subclassSelected = this.subclassSelected.filter(
        (code: string) => code !== parameters
      );
    }
    this.classcode = parameters;
    try {
      const parameter = {
        programCode: this.programcode,
        signupCode: this.signupcode,
        classCode: this.classcode,
        schoolGradeCode: 'string',
      };
      this.subClassCode = await this.dynamicReports.fetchSubClassCode(
        parameter
      );
      this.subClassCode.forEach((program: any) => {
        if (!this.subclassListSelected2.includes(program)) {
          this.subclassListSelected2.push(program);
          this.subclassCodePairs.push({
            key: this.classcode,
            value: program.description,
          });
        }
      });
      console.log(
        'Sub-Class Code List selected 2: ',
        this.subclassListSelected2
      );
      console.log('Key-Value Pair of Sub-class code: ', this.subclassCodePairs);
    } catch (error) {
      console.log('Error while fetching the Data : ' + error);
    }
  }

  async fetchSessionCode(parameters: any, isChecked: boolean) {
    console.log('teh fetch session got parameter si :' + parameters);
    this.getclasscode(parameters);
    if (isChecked) {
      if (!this.sessionSelected.includes(parameters)) {
        this.sessionSelected.push(parameters);
        this.filterList.push({key:"subclass Code", value:parameters})
      }
    } else {
      this.sessionSelected = this.sessionSelected.filter(
        (code: string) => code !== parameters
      );
    }
    this.subclasscode = parameters;

    try {
      const parameter = {
        programCode: this.programcode,
        familyId: 0,
        personId: 0,
        signupCode: this.signupcode,
      };
      this.sessionCode = await this.dynamicReports.fetchSessionCode(parameter);

      this.sessionCode.forEach((program: any) => {
        this.sessionCodePairs.push({
          key: this.subclasscode,
          value: program.description,
        });
        if (!this.sessionListSelected2.includes(program)) {
          this.sessionListSelected2.push(program);
        }
      });
      console.log('session Code List selected 2: ', this.sessionListSelected2);
      console.log('Key-Value Pair of session code: ', this.sessionCodePairs);
    } catch (error) {
      console.log('Error while fetching the session Code : ' + error);
    }
  }

  async fetchedsessionCheckBoxes(parameters: any, isChecked: boolean){
    this.filterList.push({key:"Session Code", value:parameters})

    console.log("#####the filter List are#######");
    for(let item of this.filterList){
      console.log("the filedName = "+item.key+" and the field value = "+item.value);
    }
  }

  isDropdownOpen = false;
  isDropdownOpenforprogram = false;
  isDropdownOpenforsignup = false;
  isDropdownOpenforclass = false;
  isDropdownOpenforsubclass = false;
  isDropdownOpenforsession = false;
  selectedProgramCode: string | null = null;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
    if (this.isDropdownOpenforprogram === true) {
      this.isDropdownOpenforprogram = !this.isDropdownOpenforprogram;
    }
  }
  toggleDropdownforprogram() {
    this.isDropdownOpenforprogram = !this.isDropdownOpenforprogram;
    if (this.isDropdownOpen === true) {
      this.isDropdownOpen = !this.isDropdownOpen;
    }
    // this.isDropdownOpen = !this.isDropdownOpen;
    if (this.isDropdownOpenforsignup === true) {
      this.isDropdownOpenforsignup = !this.isDropdownOpenforsignup;
    }
  }

  toggleDropdownforsignup() {
    this.isDropdownOpenforsignup = !this.isDropdownOpenforsignup;
    this.isDropdownOpenforprogram = !this.isDropdownOpenforprogram;
  }

  toggleDropdownforclass() {
    this.isDropdownOpenforclass = !this.isDropdownOpenforclass;
    this.isDropdownOpenforsignup = !this.isDropdownOpenforsignup;
  }

  toggleDropdownforsubclass() {
    this.isDropdownOpenforsubclass = !this.isDropdownOpenforsubclass;
    this.isDropdownOpenforclass = !this.isDropdownOpenforclass;
  }

  toggleDropdownforsession() {
    this.isDropdownOpenforsession = !this.isDropdownOpenforsession;
    // this.isDropdownOpenforsubclass=!this.isDropdownOpenforsubclass;
  }
  onCheckboxChange(chapterCode: string, event: any) {
    const checkbox = event.target as HTMLInputElement;
    if (checkbox) {
      this.fetchProgramCode(chapterCode, checkbox.checked);
    }
  }

  onCheckboxChangeforSignup(chapterCode: string, event: Event) {
    const checkbox = event.target as HTMLInputElement;

    if (checkbox) {
      this.fetchSignupCode(chapterCode, checkbox.checked);
    }
  }

  onCheckboxChangeforclass(chapterCode: string, event: Event) {
    const checkbox = event.target as HTMLInputElement;

    if (checkbox) {
      this.fetchClassCode(chapterCode, checkbox.checked);
    }
  }

  onCheckboxChangeforSubClass(chapterCode: string, event: Event) {
    const checkbox = event.target as HTMLInputElement;

    if (checkbox) {
      this.fetchSubClassCode(chapterCode, checkbox.checked);
    }
  }

  onCheckboxChangeforSession(chapterCode: string, event: Event) {
    const checkbox = event.target as HTMLInputElement;

    if (checkbox) {
      this.fetchSessionCode(chapterCode, checkbox.checked);
    }
  }

  onCheckboxChangeforSessionCheckboxes(chapterCode: string, event: Event){
    const checkbox = event.target as HTMLInputElement;
    if (checkbox) {
      this.fetchedsessionCheckBoxes(chapterCode, checkbox.checked);
    }
  }

  onProgramCodeChange(event: Event) {
    const selectElement = event.target as HTMLSelectElement;
    this.selectedProgramCode = selectElement.value;
    console.log('Selected Program Code:', this.selectedProgramCode);
  }

  // onprogressCodeChangessFor(event : Event){
  // const SelectElement = event.target as HTMLSelectElement;
  // this.selectedProgramCode2 = selectedElement.value;
  // console.log("the selected signup code for the ", this.selected);
  // }

  async saveReportShedule() {
    const scheduleDateString = this.sheduleSelectedDate;
    // console.log("you clicked the save report shedule function"+scheduleDateString);
    // console.log("this.familyReportName"+ this.familyReportName);
    let filterArray = this.filterList.map((item) => ({
      fieldName: item.key,
      fieldValue: item.value,
    }));

    try {
      let param = {
        reportId: this.reportId,
        reportName: this.reportName,
        filterList: filterArray,
        excelFileName: this.familyReportName,
        scheduleDate: `${scheduleDateString}:00.000Z`,
        modifiedBy: 0,
      };
      // console.log('the date and time is: ' + `${scheduleDateString}:00.000Z`);
      this.saveReportSchedule =
        await this.dynamicReports.fetchReportFilterListByReportId(param);
      console.log('the param is :+' + param);
      console.log(
        'fetched filtered Report list is : ',
        this.saveReportSchedule
      );
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }
}
