import { Component, OnInit } from '@angular/core';
import { DynamicReportService } from '../dynamicReport.service';
import { TableUtil } from 'src/app/utils/excelexport';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { TableUtil } from 'src/app/utils/excelexport';
@Component({
  selector: 'app-dynamic-report',

  templateUrl: './dynamic-report.component.html',
  styleUrls: ['./dynamic-report.component.scss'],
})
export class DynamicReportComponent implements OnInit {
  categoryList: any;
  categoryListId: number;
  subCategory: boolean = false;
  subCategoryListId: number;
  ReportListByCategoryAndSubCategory: any;
  selectedReport: any = null;
  showDiv1: boolean = false;
  activeButtonId: number | null = null;
  reportListId:any;
  isTimeoutExpires:boolean=false;
  // timesetting for downloading the reports
  timeDuration = 1 * 1000;
  // timeDuration =   2 * 60* 60 * 60 *1000;
  timeoutEnd: Date;
  currentTime: Date = new Date();
  activeContentIndex: number = -1;
  subCategoryList: any;
  reportFilterList :any;
  sheduleSelectedDate: string | null = null;
  isActive:boolean=false;
  divWidth: string = '100%';
  displayDiv: boolean = false;
  displayDiv1: boolean = false;
  displayDiv2: boolean = false;
  displayDiv3: boolean = false;
  displayDiv4: boolean = false;
  displayDiv5: boolean = false;
  chapterList: any;
  programCodeList: any;
  signUpCodeList: any;
  chapter: string;
  programcode: string;
  signupcode: string;
  chapterCode:any;
classInput: any;
subClassInput: any;
sessionInput: any;
others:any;
classCode:any;
subClassCode:any;
sessionCode:any;
// for saving selecetd dropdwon option
classcode:any;
subclasscode:any;
sessioncode:any;
signupCategory:any;
isChecked: any;
  constructor(private dynamicReports: DynamicReportService  ) {}

  buttonscolors: string[] = [
    '#F79646',
    '#55c2da',
    '#77933C',
    '#984807',
    '#948A54',
    '#002060',
    '#8064A2',
    '#0070C0',
  ];

    familyData = [
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_FRI1', registrationStatus: 'PENDING', paymentStatus: 'PARTIALLY PAID', count: 90 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_FRI1', registrationStatus: 'ACCEPTED', paymentStatus: 'PARTIALLY PAID', count: 20 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_FRI1', registrationStatus: 'ACCEPTED', paymentStatus: 'NO_DUES', count: 10 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN1', registrationStatus: 'PENDING', paymentStatus: 'PARTIALLY PAID', count: 150 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN1', registrationStatus: 'ACCEPTED', paymentStatus: 'PARTIALLY PAID', count: 20 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN1', registrationStatus: 'ACCEPTED', paymentStatus: 'NO_DUES', count: 10 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN2', registrationStatus: 'PENDING', paymentStatus: 'PARTIALLY PAID', count: 30 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN2', registrationStatus: 'ACCEPTED', paymentStatus: 'PARTIALLY PAID', count: 20 },
      { programName: 'CMWRC Membership 2024-25', session: 'BVSESSION_SUN2', registrationStatus: 'ACCEPTED', paymentStatus: 'NO_DUES', count: 3 },
    ];

  rll: { reportId: number; reportName: string }[] = [
    { reportId: 1, reportName: 'Bala vihara class Details' },
    { reportId: 2, reportName: 'Adult Education Attendance' },
    { reportId: 3, reportName: 'Arpanam Details' },
    { reportId: 4, reportName: 'Sholka class Details' },
    { reportId: 5, reportName: 'CSMD' },
    { reportId: 6, reportName: 'Chinmaya Fendrick class Details' },
    { reportId: 7, reportName: 'Pushpam' },
    { reportId: 8, reportName: 'Patram' },
    { reportId: 9, reportName: 'Palham' },
    { reportId: 10, reportName: 'Pani' },
  ];
inputArrays:string[] = ['date','string','date','dropdown','radio','checkbox'];
  ngOnInit() {
    this.fetchCategoryList();
    this.fetchChapterLists();
  }
  //  for time based download button enable
  setTimeout() {
    const now = new Date();
    this.timeoutEnd = new Date(now.getTime() + this.timeDuration);
    console.log('thi sis inside setTime out function and the now is ' + now);
    console.log('the timeoutEnd is :' + this.timeoutEnd);
  }

  isTimeoutExpired(): boolean {
    let timeOut = new Date() > this.timeoutEnd;

    return timeOut;
  }
  // For fetching category List

  async fetchCategoryList() {
    try {
      this.categoryList = await this.dynamicReports.fetchCategoryList();
      console.log('fetched category list is : ', this.categoryList);
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  // for fetching sub category list based on category
  async fetchSubCategoryList(parameters: any) {
    if(this.displayDiv){
      this.displayDiv=!this.displayDiv;
    }
    this.divWidth = '100%';

    if(!this.displayDiv){
      console.log("changed the subcat into true");
      this.displayDiv=this.displayDiv;
    }
    // if(this.displayDiv1){
    //   console.log("::::::::::it's came to if loop this.displayDiv1 ::::::::::");
    //   this.displayDiv1=!this.displayDiv1;
    //   }
    //   else if (this.displayDiv1) {
    //     console.log("::::::::it's came to else loop this.displayDiv1 ::::::::::");
    //     this.displayDiv1=!this.displayDiv1
    //   }
    this.categoryListId = parameters;
    this.subCategory = false;
    try {
      let param = {
        id: parameters,
      };
      this.subCategoryList = await this.dynamicReports.fetchSubCategoryList(
        param
      );
      console.log('fetched subCategory list is : ', this.subCategoryList);
      this.subCategory = true;
      this.isActive=true;
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

  // getting button colors dynamically
  getButtonColor(index: number): string {
    return this.buttonscolors[index % this.buttonscolors.length];
  }

  // code for exporting to excel
  exportExcel() {
    console.log('the excel icon is clicked');
//     if(!this.displayDiv5){
// this.displayDiv5=true;
//     }
// TableUtil.exportTableToExcel('familyTable','familytable data')
TableUtil.exportArrayToExcel(this.familyData,'Family Report');
    // TableUtil.exportArrayToExcel(this.totalRecList,"exportedExcelSheetofDemo");
    // this.downloadReport();
    this.displayDiv = !this.displayDiv;
    this.divWidth = '100%';
  }

  downloadReport(){
    TableUtil.exportArrayToExcel(this.familyData,'Family Report');
  }
  ReportsList(parameters: any) {
    if(this.displayDiv){
      console.log("::::::::::it's came  to ReportList if loop this.displayDiv1 ::::::::::");
      this.displayDiv=!this.displayDiv;
      }
      else{
        console.log("::::::::it's came to ReportList else loop this.displayDiv1 ::::::::::");
        this.displayDiv=this.displayDiv
      }
    this.subCategoryListId = parameters;
    this.setTimeout();
    // calling the fetchReportListByCategoryAndSubCategory
    this.fetchReportListByCategoryAndSubCategory();

    // Toggle width between 200px and 400px (or any value you like)
    this.divWidth = this.divWidth === '100%' ? '50%' : '100%';
    this.displayDiv = !this.displayDiv;
    this.displayDiv1 = !this.displayDiv1;
    this.displayDiv2 = !this.displayDiv2;
    this.displayDiv3 = !this.displayDiv3;
  }

  // fetchReportListByCategoryAndSubCategory

  async fetchReportListByCategoryAndSubCategory() {
    if(this.displayDiv1){
      console.log("::::::::::it's came  to ReportList if loop this.displayDiv1 ::::::::::");
      this.displayDiv1=!this.displayDiv1;
      }
      // else{
      //   console.log("::::::::it's came to ReportList else loop this.displayDiv1 ::::::::::");
      //   this.displayDiv1=!this.displayDiv1
      // }
    try {
      let parameters = {
        "categoryId":this.categoryListId,
        "subCategoryId": this.subCategoryListId,
        // categoryId: 0,
        // subCategoryId: 0,
      };
      this.ReportListByCategoryAndSubCategory = await this.dynamicReports.fetchReportListByCategoryAndSubCategory(parameters);
      // this.ReportListByCategoryAndSubCategory = this.rll;

      console.log(
        'fetched subCategory list is : ',
        this.ReportListByCategoryAndSubCategory
      );
      for(let item of this.ReportListByCategoryAndSubCategory){
        this.reportListId = item.reportId;
      console.log("the reportListId is "+this.reportListId);
      }
      // this.fetchReportFilterListByReportId(this.reportListId)
    } catch (error) {
      console.error('Error while fetching data: ', error);
    }
  }

async fetchReportFilterListByReportId(parameter:any){
  // this.chapterCode= null;
  // this.programcode= "";
  // this.signupcode="";

  try {
    let param = {
      id: parameter,
    };
    this.reportFilterList = await this.dynamicReports.fetchReportFilterListByReportId(param);
    console.log('fetched filtered Report list is : ', this.reportFilterList);
  } catch (error) {
    console.error('Error while fetching data: ', error);
  }
}

  Content(parameter: number) {
    this.activeContentIndex = -1;

    if (this.activeContentIndex === parameter) {
      this.activeContentIndex = -1;
    } else {
      this.sheduleSelectedDate =  null;
      this.activeContentIndex = parameter;
    }
    console.log('the parameters of index is ' + parameter);

    switch (parameter) {
      case 0:
        console.log('This is inside switch and the value is 0');
        this.displayDiv1 = !this.displayDiv1;
        break;
      case 1:
        console.log('This is inside switch and the value is 1');
        this.displayDiv1 = !this.displayDiv1;
        break;
      case 2:
        console.log('This is inside switch and the value is 2');
        this.displayDiv1 = !this.displayDiv1;
        break;
      default:
        console.log('This is inside switch and the value is default');
        this.displayDiv1 = !this.displayDiv1;
        break;
    }
  }

  Content4() {
    this.displayDiv4 = !this.displayDiv4; // Toggle the display state
  }

  setActiveButton(buttonId: number): void {
    // this.activeButtonId = buttonId;
    if (this.activeButtonId === buttonId) {
      // If the same button is clicked again, toggle off
      this.activeButtonId = null; // or -1 if you prefer
    } else {
      // Otherwise, set the new active button
      this.activeButtonId = buttonId;
    }
}
handleButtonClick(buttonId: number): void {
  // if category clicked then display 100% and and close reportList (dispdiv1)
  // this.displayDiv = !this.displayDiv;
  // this.divWidth = '100%';
  this.fetchSubCategoryList(buttonId); // Fetch subcategory list
  this.Content4(); // Perform other action
  this.setActiveButton(buttonId); // Toggle button state
}
parameter: any = 0;

// This method sets the value of 'parameter' based on the button clicked
setParameter(value: any): void {
  this.parameter = value;
}

reportSheduledfunction(){
this.isTimeoutExpires =true;
console.log("report was sheduled successfully and the sheduled date is given below ");
console.log(this.sheduleSelectedDate);
}

// for fetching of dropdownLists

 // for fetching chapterlist
 async fetchChapterLists() {
  try {
    this.chapterList = await this.dynamicReports.fetchChapterLists();
    console.log('Chapter List: ', this.chapterList);
  } catch (error) {
    console.error('Error while fetching data: ', error);
  }
}
// for fetching program code
async fetchProgramCode(chapterCode: string) {
  try {
    this.chapterCode = chapterCode;
    const parameter = { code: chapterCode, programCategory: '' };
    this.programCodeList = await this.dynamicReports.fetchProgramCode(
      parameter
    );
    // this.GasItems[index].programcode = ''; // Reset program code
    // this.programCodeList = programCodeList;
    console.log('Program Code List: ', this.programCodeList);
  } catch (error) {
    console.error('Error while fetching data: ', error);
  }
}

// for fetching signup code
async fetchSignupCode(programCode: string) {
  try {
    this.programcode = programCode;
    const parameter = { programCode: programCode };
    this.signUpCodeList = await this.dynamicReports.fetchSignUpCode(
      parameter
    );
    this.signupCategory = this.signUpCodeList.category;
    console.log('Sign Up Code List: ', this.signUpCodeList);
  } catch (error) {
    console.error('Error while fetching data: ', error);
  }
}

//  for fetching class code

async fetchClassCode(parameters:any){
  console.log("the signup code is "+parameters)
  this.signupcode=parameters;
  try{
    const parameter = {

      "programCode": this.programcode,
      "chapterCode": this.chapterCode,
      "signupCodeCategory":this.signupCategory,
      "signupCode": this.signupcode,
      "classCode": "string",
      "subClassCode": "string"
    };
    this.classCode = await this.dynamicReports.fetchClassCode(parameter);
    console.log("class code list :  "+this.classCode);
  } catch(error){
    console.error('Error while fetching the data : '+error);
  }
}
// for fetching sub class code
async fetchSubClassCode(parameters:any){
  this.classcode= parameters;
  try{
    const parameter = {
      "programCode": this.programcode,
      "signupCode": this.signupcode,
      "classCode": this.classcode,
      "schoolGradeCode": "string"
    };
    this.subClassCode = await this.dynamicReports.fetchSubClassCode(parameter);
    console.log("the sub class code is "+this.subClassCode);
  } catch (error){
    console.log("Error while fetching the Data : "+error);
  }
}

// for fetching session code

async fetchSessionCode(parameters:any){
  this.subclasscode= parameters;
  try{
    const parameter = {
      "programCode": this.programcode,
      "familyId": 0,
      "personId": 0,
      "signupCode": this.signupcode
    }
    this.sessionCode = await this.dynamicReports.fetchSessionCode(parameter);
    console.log("the session code is : "+this.sessionCode);
  } catch(error){
    console.log("Error while fetching the session Code : "+error);
  }
}










programCodeLists = [
  { code: 'code1', description: 'Description 1', selected: false },
  { code: 'code2', description: 'Description 2', selected: false },
  // Add more options here
];

isDropdownOpen = false;
isDropdownOpenforprogram =false;
isDropdownOpenforsignup=false;
isDropdownOpenforclass=false;
isDropdownOpenforsubclass=false;
isDropdownOpenforsession=false;
selectedProgramCode: string | null = null;

toggleDropdown() {
  this.isDropdownOpen = !this.isDropdownOpen;

}

toggleDropdownforprogram(){
  // if(this.isDropdownOpenforprogram)
  this.isDropdownOpenforprogram =!this.isDropdownOpenforprogram;
// else
// this.isDropdownOpenforprogram =this.isDropdownOpenforprogram;
}

toggleDropdownforsignup(){
  this.isDropdownOpenforsignup=!this.isDropdownOpenforsignup
}

toggleDropdownforclass(){
this.isDropdownOpenforclass=!this.isDropdownOpenforclass;
}

toggleDropdownforsubclass(){
  this.isDropdownOpenforsubclass=!this.isDropdownOpenforsubclass;
  }


  toggleDropdownforsession(){
    this.isDropdownOpenforsession=!this.isDropdownOpenforsession;
  }
onCheckboxChange(program: any) {
  if (program.selected) {
    this.selectedProgramCode = program.description;
  } else {
    this.selectedProgramCode = null;
  }
}
}
